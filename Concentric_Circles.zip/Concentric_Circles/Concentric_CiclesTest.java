
/**
 * Concentric Circle Test.
 *
 * @author (Jared M Kodero)
 * @version (1/24/2019)
 */
import javax.swing.JFrame;
public class Concentric_CiclesTest
{
    public static void main( String[] args)
    {
        Concentric_Circles Concentric_CirclesPanel = new Concentric_Circles ();
        JFrame newFrame = new JFrame();

        newFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        newFrame.add( Concentric_CirclesPanel);
        newFrame.setSize( 550, 550 );
        newFrame.setVisible( true );
    }
}
