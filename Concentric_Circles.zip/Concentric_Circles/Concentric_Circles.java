/**
 * Concentric Circles.
 *
 * @author (Jared M Kodero)
 * @version (1/24/2019)
 */
import java.awt.Graphics;
import javax.swing.JPanel;

public class Concentric_Circles extends JPanel{

    public void paintComponent(Graphics g){
        super.paintComponent(g);
        //calculates the centre of the frame
        //int widthMiddle = ((getWidth()) / 2);
        //int heightMiddle = ((getHeight()) / 2);

        int width = getWidth();
        int height = getHeight();       
        System.out.printf("Width is %d \t and height is %d\n", width, height );

        //calculates the centre of the panel

        int xPoint = width / 2;
        int yPoint = height / 2;

        for(int i = 0; i < 10; i++){
            g.drawOval(xPoint - (i * 5), yPoint - (i * 5), (i * 10), (i * 10));
            //System.out.printf("Width is %d \t and height is %d\n", xPoint, yPoint );

        }

    }
}
