
/**
 * 
 * Page 68 2.25, determine whether an input integer
 *
 * @author (Jared M Kodero)
 * @version (1/14/2019)
 */
import java.util.Scanner;
public class Ex2_25
{
    

   public static void main(String[] args)
   {
       Scanner input = new Scanner(System.in);
       int number = 0;
       
       System.out.print("Enter an integer: ");
       number = input.nextInt();
       
       if ( (number % 2) == 0 )
          System.out.printf("%d is even", number );
       
       if ( (number % 2) != 0 )
          System.out.printf("%d is odd", number);
       
   }// end main
}// end class OddEven

