
/**
 * Write a description of class HelloWorld here.
 *Output a line of text 
 * @author (Jared M Kodero)
 * @version (1/10/2018)
 */
public class HelloWorld
{
    public static void main( String[] args)
    {
        System.out.println("Hello World!" );
        System.out.println( "" );
        System.out.println("Hello\n" );
      
        System.out.println("World!\n" );
        System.out.println("Today is January 8, 2019" );
        System.out.printf("Today is %s %d, %d","January", 8 , 2019 );
    }// End Main
}//End Class Hello World
