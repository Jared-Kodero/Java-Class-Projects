
/**
 * break down a 5 digit number to digits.
 *
 * @author (Jared M Kodero)
 * @version (1/14/2019)
 */
import java.util.Scanner;
public class Ex2_30
{
   public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        int number = 0;
        int firstDigit = 0;
        int secondDigit = 0;
        int thirdDigit = 0;
        int fourthDigit = 0;
        int fifthDigit = 0;
        
        
        System.out.print("Enter a five digit number: ");
        number = input.nextInt();
        
        firstDigit = number / 10000;
        secondDigit = number % 10000 / 1000;
        thirdDigit = number % 1000 / 100;
        fourthDigit = number % 100 / 10;
        fifthDigit = number % 10;
        
        System.out.println ();
         
        System.out.printf ("%d   %d   %d   %d   %d\n", firstDigit,secondDigit ,thirdDigit, 
               fourthDigit ,fifthDigit);
    }// end main 
}
