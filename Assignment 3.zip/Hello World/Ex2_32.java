
/**
 * Negative, Positive And Zero Values
 *
 * @author (Jared M Kodero)
 * @version (1/14/2019)
 */
import java.util.Scanner;
public class Ex2_32
{
  {
 
 Scanner value = new Scanner (System.in);
 
        int num1;
 int num2;
 int num3;
 int num4;
 int num5; 
        int numPositive = 0; //variable to count how many positive numbers initialized to zero
        int numZero = 0; //variable to count how many numbers are zero initialized to zero
        int numNegative = 0; //variable to count how many negative numbers initialized to zero
         
        System.out.print ("Enter Your First Number: ");
        num1 = value.nextInt();
        System.out.print ("Enter Your Second Number: ");
        num2 = value.nextInt();
        System.out.print ("Enter Your Third Number: ");
        num3 = value.nextInt();
        System.out.print ("Enter Your Fourth Number: ");
        num4 = value.nextInt();
        System.out.print ("Enter Your Fifth Number: ");
        num5 = value.nextInt();
         
        //count negative numbers
         
        if (num1 < 0) 
            numNegative = numNegative + 1;
        if (num2 < 0) 
            numNegative = numNegative + 1;
        if (num3 < 0) 
            numNegative = numNegative + 1;
        if (num4 < 0) 
            numNegative = numNegative + 1;
        if (num5 < 0) 
            numNegative = numNegative + 1;
 
 //count positive numbers
         
        if (num1 > 0) 
            numPositive = numPositive + 1;
        if (num2 > 0) 
            numPositive = numPositive + 1;
        if (num3 > 0) 
            numPositive = numPositive + 1;
        if (num4 > 0) 
            numPositive = numPositive + 1;
        if (num5 > 0)
            numPositive = numPositive + 1;
         
        //count number of zeros
         
        if (num1 == 0) 
            numZero = numZero + 1;
        if (num2 == 0) 
            numZero = numZero + 1;
        if (num3 == 0) 
            numZero = numZero + 1;
        if (num4 == 0) 
            numZero = numZero + 1;
        if (num5 == 0) 
            numZero = numZero + 1;
         
        System.out.println ("\n"); 
 
        System.out.printf ("Negative numbers = %d\n", numNegative);
        System.out.printf ("Positive numbers = %d\n", numPositive);
        System.out.printf ("Zeros = %d\n", numZero);
 
    }  
}
