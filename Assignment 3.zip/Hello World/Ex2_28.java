
/**
 * Diameter, Circumference and Area of a Circle
 *
 * @author (Jared M Kodero)
 * @version (1/14/2019)
 */
import java.util.Scanner;
public class Ex2_28
{
  
    public static void main (String [] args) {
 
  Scanner value = new Scanner (System.in);
         
        int radius;
         
        System.out.println ("This Application \n");
         
        System.out.print ("Enter The Value For The Radius of The Circle: ");
        radius = value.nextInt();
         
        System.out.printf("\nThe diameter of the circle is %d\nThe circumference "
                + "of the circle is %f\nThe Area of the circle is %f\n",
                (2*radius), (2*Math.PI*radius), (Math.PI*radius*radius));
 
    }
}
 

