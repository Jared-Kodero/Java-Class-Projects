
/**

 * * My Rectangle.
 * @author (Jared M Kodero)
 * @version (2/21/2019)
 */
import java.awt.Color;
import java.awt.Graphics;
public class MyRectangle extends MyShape 
{
    private Color myColor; // Color of this rectangle
    private boolean filled; // whether this shape is filled
    // constructor initializes private vars with default values
    public MyRectangle()
    {
        this( 0, 0, 0, 0, Color.BLACK, false ); // call constructor
    } // end MyRect no-argument constructor

    // constructor with input values
    public MyRectangle( int x1, int y1, int x2, int y2,
    Color color, boolean isFilled )
    {
        super(x1,y1,x2,y2); //calls base class constructor
        setColor( color ); // set the color
        setFilled( isFilled );
    } // end MyRect constructor

    //sets color
    public void setColor( Color color )
    {
        myColor = color;
    } // end method setColor

    // get the color
    public Color getColor()
    {
        return myColor;
    } // end method getColor

    // get upper left x coordinate
    public int getUpperLeftX()
    {
        return Math.min( getX1(), getX2() );
    } // end method getUpperLeftX

    // get upper left y coordinate
    public int getUpperLeftY()
    {
        return Math.min( getY1(), getY2() );
    } // end method getUpperLeftY

    // get shape width
    public int getWidth()
    {
        return Math.abs( getX2() - getX1() );
    } // end method getWidth

    // get shape height
    public int getHeight()
    {
        return Math.abs( getY2() - getY1() );
    } // end method getHeight

    // determines whether this shape is filled
    public boolean isFilled()
    {
        return filled;
    } // end method is filled

    // sets whether this shape is filled
    public void setFilled( boolean isFilled )
    {
        filled = isFilled;
    } // end method setFilled

    // draws a rectangle in the specified color
    public void draw( Graphics g )
    {
        g.setColor( getColor() );
        if ( isFilled() )
            g.fillRect( getUpperLeftX(), getUpperLeftY(),
                getWidth(), getHeight() );
        else
            g.drawRect( getUpperLeftX(), getUpperLeftY(),
                getWidth(), getHeight() );
    } // end method draw
} // end class MyRect