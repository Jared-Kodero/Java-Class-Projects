
/**
 * Draw Panel Test
 *
 * @author (Jared M Kodero)
 * @version (2/21/2019)
 */

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
public class DrawPanelTest
{
    public static void main(String[] args)
    {
        final int WINDOW_WIDTH = 300, WINDOW_HEIGHT = 300;
        JFrame application = new JFrame (); // the window and its components
        DrawPanel panel = new DrawPanel (); // call constructor creating MyLine objects
        JLabel southLabel = new JLabel(panel.status());
        application.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        application.add (panel);
        application.setSize (WINDOW_WIDTH, WINDOW_HEIGHT);
        application.setVisible (true); // show the window
        application.add(southLabel, BorderLayout.SOUTH);
    }
}