
/**
 * Write a description of class MyRectangle here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.awt.Color;
import java.awt.Graphics;
public class MyRectangle extends MyBoundedShape
{
    public MyRectangle()
    {
        super();

    }


    public MyRectangle( int x1, int y1, int x2, int y2,
    Color color, boolean isFilled )
    {
        super(x1,y1,x2,y2); //calls base class constructor
        setColor( color ); // set the color
        setFilled( isFilled );
    } // end MyRect constructor

    public void draw ( Graphics g ) 
    {
        g.setColor( getColor() );
        if ( isFilled() )
            g.fillRect( upperLeftX(), upperLeftY(),
                width(), length() );
        else
            g.drawRect( upperLeftX(), upperLeftY(),
                width(), length() );

    }
}
