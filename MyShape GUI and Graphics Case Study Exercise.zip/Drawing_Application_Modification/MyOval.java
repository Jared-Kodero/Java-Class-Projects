
/**
 * Write a description of class MyOval here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.awt.Color;
import java.awt.Graphics;
public class MyOval extends MyBoundedShape
{
    
    public MyOval()
    {
        super();

    }


    public MyOval( int x1, int y1, int x2, int y2,
    Color color, boolean isFilled )
    {
        super(x1,y1,x2,y2); //calls base class constructor
        setColor( color ); // set the color
        setFilled( isFilled );
    } // end MyRect constructor

    public void draw ( Graphics g ) 
    {
        g.setColor( getColor() );
        if ( isFilled() )
            g.fillOval( upperLeftX(), upperLeftY(),
                width(), length() );
        else
            g.drawOval( upperLeftX(), upperLeftY(),
                width(), length() );

    }
}


