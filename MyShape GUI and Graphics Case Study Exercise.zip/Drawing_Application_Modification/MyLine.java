
/**
 * My Line.
 *
 * @author (Jared M Kodero)
 * @version (2/21/2019)
 */
import java.awt.Color;
import java.awt.Graphics;
public class MyLine extends MyShape
{
    private Color myColor; // color of this shape
    // constructor initializes private vars with default values
    public MyLine()
    {
        this( 0, 0, 0, 0, Color.BLACK ); // call constructor to set values
    } // end MyLine no-argument constructor
    // constructor with input values
    public MyLine( int x1, int y1, int x2, int y2, Color color )
    {
        super(x1,y1,x2,y2); //calls base class constructor
        setColor( color ); // set the color
    } // end MyLine constructor
    // set the color
    public void setColor( Color color )
    {
        myColor = color;
    } // end method setColor
    // get the color
    public Color getColor()
    {
        return myColor;
    } // end method getColor
    // draw the line in the specified color
    public void draw( Graphics g )
    {
        g.setColor( getColor() );
        g.drawLine( getX1(), getY1(), getX2(), getY2() );
    } // end method draw
} // end class MyLine extends MyShape