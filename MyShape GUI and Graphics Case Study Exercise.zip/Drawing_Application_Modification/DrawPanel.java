
/**
 * Draw Panel.
 *
 * @author (Jared M Kodero)
 * @version (2/21/2019)
 */
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import javax.swing.JPanel;
public class DrawPanel extends JPanel
{
    private Random randomNumbers = new Random();
    private MyLine lines[]; // array on lines
    private MyOval ovals[]; // array of ovals
    private MyRectangle rectangles[]; // array of rectangles
    // constructor, creates a panel with random shapes
    public DrawPanel()
    {
        setBackground( Color.WHITE );
        lines = new MyLine[ 1 + randomNumbers.nextInt( 5 ) ];
        ovals = new MyOval[ 1 + randomNumbers.nextInt( 5 ) ];
        rectangles = new MyRectangle[ 1 + randomNumbers.nextInt( 5 ) ];
        // create lines
        for ( int count = 0; count < lines.length; count++ )
        {
            // generate random coordinates
            int x1 = randomNumbers.nextInt( 300 );
            int y1 = randomNumbers.nextInt( 300 );
            int x2 = randomNumbers.nextInt( 300 );
            int y2 = randomNumbers.nextInt( 300 );
            // generate a random color
            Color color = new Color( randomNumbers.nextInt( 256 ),
                    randomNumbers.nextInt( 256 ), randomNumbers.nextInt( 256 ) );
            // add the line to the list of lines to be displayed
            lines[ count ] = new MyLine( x1, y1, x2, y2, color );
        } // end for
        // create ovals
        for ( int count = 0; count < ovals.length; count++ )
        {
            // generate random coordinates
            int x1 = randomNumbers.nextInt( 300 );
            int y1 = randomNumbers.nextInt( 300 );
            int x2 = randomNumbers.nextInt( 300 );
            int y2 = randomNumbers.nextInt( 300 );
            // generate a random color
            Color color = new Color( randomNumbers.nextInt( 256 ),
                    randomNumbers.nextInt( 256 ), randomNumbers.nextInt( 256 ) );
            // get filled property
            boolean filled = randomNumbers.nextBoolean();
            // add the line to the oval of ovals to be displayed
            ovals[ count ] = new MyOval( x1, y1, x2, y2, color, filled );
        } // end for
        // create rectangles
        for ( int count = 0; count < rectangles.length; count++ )
        {
            // generate random coordinates
            int x1 = randomNumbers.nextInt( 300 );
            int y1 = randomNumbers.nextInt( 300 );
            int x2 = randomNumbers.nextInt( 300 );
            int y2 = randomNumbers.nextInt( 300 );

            // generate a random color
            Color color = new Color( randomNumbers.nextInt( 256 ),
                    randomNumbers.nextInt( 256 ), randomNumbers.nextInt( 256 ) );

            // get filled property
            boolean filled = randomNumbers.nextBoolean();

            // add the rectangle to the list of rectangles to be displayed
            rectangles[ count ] = new MyRectangle( x1, y1, x2, y2, color, filled );
        } // end for
    } // end DrawPanel constructor

    // for each shape array, draw the individual shapes
    public void paintComponent( Graphics g )
    {
        super.paintComponent( g );

        // draw the lines
        for ( MyLine line : lines )
            line.draw( g );

        // draw the ovals
        for ( MyOval oval: ovals )
            oval.draw( g );

        // drat the rectangles
        for ( MyRectangle rectangle : rectangles )
            rectangle.draw( g );

    } // end method paintComponent

    public String status()
    {
        // returns number of lines,ovals,rectangles which are drawn in the panel in a string format
        return String.format("%s: %d, %s: %d, %s:%d", "lines",lines.length,"ovals",ovals.length,"rectangles",rectangles.length);
    }
} // end class DrawPanel