
/**
 *  Write a method integerPower( base, exponent ) that returns the value of base exponent .
 *
 * @author (Jared M Kodero)
 * @version (2/3/2019)
 */
import java.util.Scanner;
public class Exponentiation5_14
{
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);


        //Initialize Variables
        long base = 0;

        int exponent = 0;



        while(base != -1){

            System.out.print("Enter base (-1 to exit): ");

            base = sc.nextInt();



            if(base != -1){

                System.out.print("Enter exponent: ");

                exponent = sc.nextInt();



                System.out.println(Math.pow(base, exponent));



                System.out.printf("%d^%d: %d\n",

                        base, exponent, integerPower(base, exponent));

            }//End if

        }//End While

    }

    public static long integerPower(long base, int exponent){

        // base condition

        if(exponent <= 1)

            return base;



        // call self after calculating power with reduced exponent

        return base * integerPower(base, --exponent);

    }
}
