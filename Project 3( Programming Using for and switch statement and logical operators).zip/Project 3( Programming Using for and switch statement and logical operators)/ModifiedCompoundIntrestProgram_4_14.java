
/**
 * Modified Compound Intrest Program 4.14
 *
 * @author (Jared M Kodero)
 * @version (2/1/2019)
 */
public class ModifiedCompoundIntrestProgram_4_14
{
    public static void main( String[] args)
    {
        double ammount; //ammoun on deposit for each year
        double principal = 1000.0; //intial ammount before interest
        //double rate = 0;//interset rate
        
        //Dispaly Headers
        System.out.println(" 5% Interest Rate ");
        System.out.printf( "%s%20s\n","Year","Ammount on deposit" );
        
        //calculate the ammount for specified year.
        for (int year = 1; year <= 10; year++)
        
            {
                //Calculate the ammount for a new specified year
                ammount = principal * Math.pow( 1.0 + 0.05, year );
                
                //display the year and the ammount
                System.out.printf ( "%4d%,20.2f\n",year, ammount);
            }//end for
            
            System.out.println(" 6% Interest Rate");
            System.out.printf( "%s%20s\n","Year","Ammount on deposit" );
        
        //calculate the ammount for specified year.
        
        for (int year = 1; year <= 10; year++)
             
        
            {
                //Calculate the ammount for a new specified year
                ammount = principal * Math.pow( 1.0 + 0.06, year );
                
                //display the year and the ammount
                System.out.printf ( "%4d%,20.2f\n",year, ammount);
            }//end for
        
            System.out.println(" 7% Interest Rate ");
            System.out.printf( "%s%20s\n","Year","Ammount on deposit" );
        
        //calculate the ammount for specified year.
        
        for (int year = 1; year <= 10; year++)
             
        
            {
                //Calculate the ammount for a new specified year
                ammount = principal * Math.pow( 1.0 + 0.07, year );
                
                //display the year and the ammount
                System.out.printf ( "%4d%,20.2f\n",year, ammount);
            }//end for
             
             System.out.println(" 8% Interest Rate");
             System.out.printf( "%s%20s\n","Year","Ammount on deposit" );
        
        //calculate the ammount for specified year.
        
        for (int year = 1; year <= 10; year++)
             
        
            {
                //Calculate the ammount for a new specified year
                ammount = principal * Math.pow( 1.0 + 0.08, year );
                
                //display the year and the ammount
                System.out.printf ( "%4d%,20.2f\n",year, ammount);
            }//end for
             
            System.out.println(" 9% Interest Rate ");
             System.out.printf( "%s%20s\n","Year","Ammount on deposit" );
        
        //calculate the ammount for specified year.
        
        for (int year = 1; year <= 10; year++)
             
        
            {
                //Calculate the ammount for a new specified year
                ammount = principal * Math.pow( 1.0 + 0.09, year );
                
                //display the year and the ammount
                System.out.printf ( "%4d%,20.2f\n",year, ammount);
            }//end for
            
             System.out.println(" 10 % Interest Rate ");
             System.out.printf( "%s%20s\n","Year","Ammount on deposit" );
        
        //calculate the ammount for specified year.
        
        for (int year = 1; year <= 10; year++)
             
        
            {
                //Calculate the ammount for a new specified year
                ammount = principal * Math.pow( 1.0 + 0.10, year );
                
                //display the year and the ammount
                System.out.printf ( "%4d%,20.2f\n",year, ammount);
            }//end for
        
        
        
        
        
    }//end main
}//end class
