
/**
 * Modified Triangle Printing program.
 *
 * @author (Jared M Kodero)
 * @version (2/1/2019)
 */
public class ModifiedTrianglePrintingProgram_4_22
{
  public static void main(String[] args)
    {
        int row,column, space;
        
        //print one rw at a time ,tabbing between triangles
        for (row = 1; row <= 10; row++)
            {
                //Triangle 1
                for (column = 1; column <= row; column++)
                    System.out.print('*');
                for (space = 1; space <= 10 - row; space++)
                    System.out.print(' ');
                    System.out.print("\t");
                    
                //Triangle 2
                for ( column = 10; column >= row; column-- ) 
                       System.out.print( '*' );
                for ( space = 1; space < row; space++ ) 
                       System.out.print( ' ' ); 
                       System.out.print( "\t" );
                       
                //Triangle 3
                for ( space = 1; space < row; space++ )
                     System.out.print( ' ' );
                for ( column = 10; column >= row; column-- )
                    System.out.print( '*' );
                     System.out.print( "\t" ); 
                     
                //Triangle 4
                for ( space = 10; space > row; space-- ) 
                    System.out.print( ' ' ); 
                for ( column = 1; column <= row; column++ )
                     System.out.print( '*' ); 
                     System.out.println(); 
                     
                 
                
                       
                
                       
                      
                
                    
                    
            }//End For
        
    }//End Main
  

       

    
}// End Class