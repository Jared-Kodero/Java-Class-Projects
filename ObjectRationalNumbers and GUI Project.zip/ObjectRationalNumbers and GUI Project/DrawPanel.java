
/**
 * Draw Panel
 *
 * @author (Jared M Kodero)
 * @version (2/17/2019)
 */
//DrawPanel.java
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import javax.swing.JPanel;
public class DrawPanel extends JPanel
{
    private Random randomNumbers = new Random();
    private MyLine lines[]; 
    private MyOval ovals[]; 
    private MyRectangle rectangles[]; 
    
    public DrawPanel()
    {
        setBackground( Color.WHITE );
        lines = new MyLine[ 1 + randomNumbers.nextInt( 5 ) ];
        ovals = new MyOval[ 1 + randomNumbers.nextInt( 5 ) ];
        rectangles = new MyRectangle[ 1 + randomNumbers.nextInt( 7 ) ];
        
        // create lines
        for ( int count = 0; count < lines.length; count++ )
        {
            // generate random coordinates
            int x1 = randomNumbers.nextInt( 400 );
            int y1 = randomNumbers.nextInt( 400 );
            int x2 = randomNumbers.nextInt( 400 );
            int y2 = randomNumbers.nextInt( 400 );
            // generate a random color
            Color color = new Color( randomNumbers.nextInt( 256 ),
                    randomNumbers.nextInt( 256 ), randomNumbers.nextInt( 256 ) );
            // add the line to the list of lines to be displayed
            lines[ count ] = new MyLine( x1, y1, x2, y2, color );
        } // end for
        
        
        // create ovals
        
        
        for ( int count = 0; count < ovals.length; count++ )
        {
            // generate random coordinates
            int x1 = randomNumbers.nextInt( 400 );
            int y1 = randomNumbers.nextInt( 400 );
            int x2 = randomNumbers.nextInt( 400 );
            int y2 = randomNumbers.nextInt( 400 );
            // generate a random color
            Color color = new Color( randomNumbers.nextInt( 256 ),
                    randomNumbers.nextInt( 256 ), randomNumbers.nextInt( 256 ) );
            // get filled property
            boolean filled = randomNumbers.nextBoolean();
            // add the line to the oval of ovals to be displayed
            ovals[ count ] = new MyOval( x1, y1, x2, y2, color, filled );
        } // end for
        
        
        // create rectangles
        
        
        for ( int count = 0; count < rectangles.length; count++ )
        {
            // generate random coordinates
            int x1 = randomNumbers.nextInt( 400 );
            int y1 = randomNumbers.nextInt( 400);
            int x2 = randomNumbers.nextInt( 400 );
            int y2 = randomNumbers.nextInt( 400 );

            // generate a random color
            Color color = new Color( randomNumbers.nextInt( 256 ),
                    randomNumbers.nextInt( 256 ), randomNumbers.nextInt( 256 ) );

            // get filled property
            boolean filled = randomNumbers.nextBoolean();

            // add the rectangle to the list of rectangles to be displayed
            rectangles[ count ] = new MyRectangle( x1, y1, x2, y2, color, filled );
        } // end for
    } // end DrawPanel constructor

    
    
    
    
    // for each shape array, draw the individual shapes
    public void paintComponent( Graphics g )
    {
        super.paintComponent( g );

        // draw the lines
        for ( MyLine line : lines )
            line.draw( g );

        // draw the ovals
        for ( MyOval oval: ovals )
            oval.draw( g );

        // drat the rectangles
        for ( MyRectangle rectangle : rectangles )
            rectangle.draw( g );

    } // end method paintComponent

    
    
    
    
    
    
    
    
    
    //Test Draw
    
    public static void main(String[] args)
    {
        final int WINDOW_WIDTH = 400, WINDOW_HEIGHT = 400;
        
        JFrame application = new JFrame (); 
        
        DrawPanel panel = new DrawPanel (); 
        
        
        
        application.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        
        application.add (panel);
        
        application.setSize (WINDOW_WIDTH, WINDOW_HEIGHT);
        
        application.setVisible (true); // show the window
        
    }
} // end class DrawPanel

