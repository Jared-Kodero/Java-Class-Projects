 
/**
 * RationalNumber Test.
 *
 * @author (Jared M Kodero)
 * @version (2/14/2019)
 */
import java.util.Scanner;
public class RationalNumberTest
{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
           
            System.out.println(" Enter RationalNumber No 1 ::");
            
            System.out.print("Enter Numerator =");
            
            int num1 = sc.nextInt();
            
            System.out.print("Enter Denominator =");
            
            int denom1 = sc.nextInt();
            
            //Getting the second RationalNumber number From the user
            System.out.println(":: Enter RationalNumber No 2 ::");
            
            System.out.print("Enter Numerator =");
            
            int num2 = sc.nextInt();
            
            System.out.print("Enter Denominator =");
            
            int denom2 = sc.nextInt();

            //Creating the objects to RationalNumber Class
            RationalNumber r1 = new RationalNumber(num1, denom1);
            
            RationalNumber r2 = new RationalNumber(num2, denom2);
            
            System.out.println(" ");

            // Reducing the RationalNumber Numbers
            System.out.println("** RationalNumber Reduced Forms **");

            System.out.println("(" + num1 + "/" + denom1 + ") reduced to :" + r1.toString());

            System.out.println("(" + num2 + "/" + denom2 + ") reduced to :" + r2.toString());

            System.out.println("RationalNumber Number #1 in Decimal Form :" + r1.toDecimal());
            
            System.out.println("RationalNumber Number #2 in Decimal Form :" + r2.toDecimal());

            System.out.println("\n** Adding two RationalNumber Numbers **");
            // Addition of two RationalNumber Numbers
            
            RationalNumber r11 = RationalNumber.add(r1, r2);
            
            System.out.println("(" + r1.toString() + ") + " + "(" + r2.toString() + ") = " + r11.toString());
            
            System.out.println("\n** Subtracting two RationalNumber Numbers **");
            
            RationalNumber r12 = RationalNumber.subtract(r1, r2);
            
            System.out.println("(" + r1.toString() + ") - " + "(" + r2.toString() + ") = " + r12.toString());
            
            System.out.println("\n** Multiplying two RationalNumber Numbers **");
            
            RationalNumber r13 = RationalNumber.multiply(r1, r2);
            
            System.out.println("(" + r1.toString() + ") * " + "(" + r2.toString() + ") = " + r13.toString());
            
            System.out.println("\n** Dividing two RationalNumber Numbers **");
            
            RationalNumber r14 = RationalNumber.divide(r1, r2);
            
            System.out.println("(" + r1.toString() + ") / " + "(" + r2.toString() + ") = " + r14.toString());

            System.out.println("\n** Comparing two RationalNumber Numbers **");

            System.out.print("Do you want to continue(Y/N):");
            
            char c = sc.next(".").charAt(0);
            
            
            if (c == 'Y' || c == 'y')
                continue;
            else {
                System.out.println(":: Program Exit ::");
                break;
            }
        }

    }//End Class

}

