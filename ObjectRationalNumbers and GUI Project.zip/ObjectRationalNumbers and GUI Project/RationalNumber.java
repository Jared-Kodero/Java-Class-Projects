
/**
 * Write a description of class RationalNumberNumbers here.
 *
 * @author (Jared M Kodero)
 * @version (2/20/2019)
 */
import java.text.DecimalFormat;
public class RationalNumber
{
    private int numerator, denominator;

    public RationalNumber(int a, int b) {
        numerator = a;
        denominator = b;

        if (denominator < 0) {
            denominator = denominator * -1;

            numerator = numerator * -1;
        } else if (denominator == 0) {
            denominator = 1;
            numerator = 0;
        }
        RationalNumber.this.reduce();

    }

    public RationalNumber() {
        denominator = 1;
        numerator = 0;
    }
    //Setters and Getters
    public void setNumerator(int a) {
        numerator = a;
        RationalNumber.this.reduce();

    }

    public int getNumerator() {
        return numerator;
    }

    public void setDenominator(int b) {
        if (b < 0) {
            b = b * -1;
            denominator = b;
            if (numerator < 0) {;
            } else {
                numerator = getNumerator() * -1;

            }

        } else if (b == 0) {
            setNumerator(0);
            setDenominator(1);

        } else {
            denominator = b;
        }
        RationalNumber.this.reduce();

    }

    public int getDenominator() {
        return denominator;
    }

    public String toString() {
        String stringFormat = numerator + " / " + denominator;
        return stringFormat;
    }

    public static RationalNumber add(RationalNumber r1, RationalNumber r2) {
        int num1 = r1.getNumerator();

        int denom1 = r1.getDenominator();
        int num2 = r2.getNumerator();
        int denom2 = r2.getDenominator();
        int num3 = (num1 * denom2) + (num2 * denom1);
        int denom3 = denom1 * denom2;
        RationalNumber res = new RationalNumber(num3, denom3);
        return res;
    }
    //Method which adding two RationalNumber numbers
    public static RationalNumber subtract(RationalNumber r1, RationalNumber r2) {
        int num1 = r1.getNumerator();
        int denom1 = r1.getDenominator();
        int num2 = r2.getNumerator();
        int denom2 = r2.getDenominator();
        int num3 = (num1 * denom2) - (num2 * denom1);
        int denom3 = denom1 * denom2;
        RationalNumber res = new RationalNumber(num3, denom3);
        return res;
    }
    //Method which adding two RationalNumber numbers
    public static RationalNumber multiply(RationalNumber r1, RationalNumber r2) {
        int num1 = r1.getNumerator();
        int denom1 = r1.getDenominator();
        int num2 = r2.getNumerator();
        int denom2 = r2.getDenominator();
        int num3 = (num1 * num2);
        int denom3 = denom1 * denom2;
        RationalNumber res = new RationalNumber(num3, denom3);
        return res;
    }
    //Method which adding two RationalNumber numbers
    public static RationalNumber divide(RationalNumber r1, RationalNumber r2) {
        int num1 = r1.getNumerator();
        int denom1 = r1.getDenominator();
        int num2 = r2.getNumerator();
        int denom2 = r2.getDenominator();
        int num3 = (num1 * denom2);
        int denom3 = (num2 * denom1);
        RationalNumber res = new RationalNumber(num3, denom3);
        return res;
    }

    public String reduce() {
        // determine the greatest common divisor
        int gcd = this.gcd(numerator, denominator);
        // if GCD is negative, change to positive
        if (gcd < 0) {
            gcd = -gcd;
        }
        // divide gcd into both numerator and denominator
        numerator = numerator / gcd;
        denominator = denominator / gcd;

        return numerator + "/" + denominator;
    }

    private Integer gcd(Integer a, Integer b) {
        if ((a % b) == 0) {
            return b;
        }
        // recursive case
        else {
            return gcd(b, a % b);
        }
    }

    //Displaying the RationalNumberNumber in Decimal Format
    public String toDecimal() {
        // DecimalFormat class is used to format the output
        DecimalFormat df = new DecimalFormat("00.00");
        return df.format(((float)(numerator) / denominator));
    }

}