
/**
 * Random generated Shapes.
 *
 * @author (Jared M Kodero)
 * @version (2/11/2019)
 */
import javax.swing.JFrame;
public class RandomShapesTest extends JFrame
{
    public static void main(String[] args){

        RandomShapes panel = new RandomShapes();



        JFrame application = new JFrame();



        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        application.add(panel);

        application.setSize(250, 250);

        application.setVisible(true);

    }
}
