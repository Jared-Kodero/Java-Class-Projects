
/**
 * Randomly Generated Shapes.
 *
 * @author (Jared M Kodero)
 * @version (2/11/2019)
 */
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;
import java.util.Random;
public class RandomShapes extends JPanel
{
      Random randomGenerator = new Random();



    public void paintComponent(Graphics g){

        super.paintComponent(g);



        int width = getWidth();

        int height = getHeight();



        for(int i=0; i<10; i++){



            // set random colour

            Color color = new Color(randomGenerator.nextInt(255),

                                    randomGenerator.nextInt(255),

                                    randomGenerator.nextInt(255));



            g.setColor(color);



            // determine shaped and set coords/size

            if(randomGenerator.nextInt(2) == 0)

                g.fillRect(randomGenerator.nextInt(width),

                           randomGenerator.nextInt(height),

                           randomGenerator.nextInt(width / 2),

                           randomGenerator.nextInt(height / 2));

            else

                g.fillOval(randomGenerator.nextInt(width),

                           randomGenerator.nextInt(height),

                           randomGenerator.nextInt(width / 2),

                           randomGenerator.nextInt(height / 2));

        }

    }
}
