
/**
 * OVALS.
 * Using drawLine to connect corners of a panel
 * 
 * @author (JARED M KODERO)
 * @version (1/24/2019) 
 */
import java.awt.Graphics;
import javax.swing.JPanel;

public class Ovals_3_2b extends JPanel
{
    // drawa an X from the corners of the panel
    public void paintComponent( Graphics g )
    {
        // call paintComponent to ensure the panel display correctly
        super.paintComponent(g);
        
        int width = getWidth();   // total width
        int height = getHeight(); // total height
        
      {  // draw 15 lines
        int counter = 1;
    
        while ( counter <= 15 )
        {
                      
            g.drawLine( 0, 0 + height / 15 * ( counter -1 ),
                      width / 15 * counter,          
                      height );
        
            counter++;
            
            
        
                     
            
        }
        
        for (int i  = 1; i <= 15; i++)
        {
            g.drawLine(width - width/15 * (i-1), 0, 0, height/15 * i);
            
        }
        
         
        int x = 1;
    
        while ( x <= 15 )
        {
                      
            g.drawLine(0 + height / 15 * ( x -1 ),0,
                      height,          
                      width / 15 * x);
        
            x++;
            
            
            
        
                     
            
        }
        
        int q = 1;
    
        while ( x <= 15 )
        {
                      
            g.drawLine(0,0 + height / 15 * ( q-1 ),
                      width,          
                      height / 15 * x);
        
            q++;
            
            
            
        
                     
            
        }
        
            
        
                     
            
        
        
    }   
                        
    } // end method
    
} // end class

