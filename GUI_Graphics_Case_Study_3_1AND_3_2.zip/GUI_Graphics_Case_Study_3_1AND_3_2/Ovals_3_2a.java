
/**
 * Ovals.
 * Using drawLine to connect corners of a panel
 * 
 * @author (Jared M Kodero)
 * @version (!/24/2019) 
 */
import java.awt.Graphics;
import javax.swing.JPanel;

public class Ovals_3_2a extends JPanel
{
    // drawa an X from the corners of the panel
    public void paintComponent( Graphics g )
    {
        // call paintComponent to ensure the panel display correctly
        super.paintComponent(g);
        
        int width = getWidth();   // total width
        int height = getHeight(); // total height
        
        // draw 15 lines
        int counter = 1;
        
        while ( counter <= 15 )
        {
                      
            g.drawLine( 0, 0 + height / 15 * ( counter -1 ),
                      width / 15 * counter,          
                      height );
        
            counter++;
            
            
        
                     
            
        }
        
        
        
                
           
                        
    } // end method
    
} // end class

