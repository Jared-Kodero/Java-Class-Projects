    
/**
 * Addition program that inputs two integer numbers from dialog
 * and display their sum in dialog
 *
 * @
 * @1/10/2019
 */
// import java.util.Scanner; // program uses class Scanner
import javax.swing.JOptionPane;

public class Addition2_1
{
    public static void main( String[] args )
    {
        // create Scanner object to obtain the input from command window
        //Scanner input = new Scanner( System.in );
        
        int number1; // the first number
        int number2; // the second number
        int sum;
        //// create a dialog for number1 input
        String number1Str = 
           JOptionPane.showInputDialog("Enter first number: " );
        number1 = Integer.parseInt(number1Str);
        
        String number2Str = 
           JOptionPane.showInputDialog("Enter Second number: " );
        number2 = Integer.parseInt(number2Str);
        //System.out.print( "Enter first number: " ); // prompt
        //number1 = input.nextInt();
        //// create a dialog for number2 input
        //System.out.print( "Enter second number: " ); // prompt
        //number2 = input.nextInt();
        
        sum = number1 + number2; // add the two numbers and store in sum
        
        //// create the message string
        String message = String.format("The sum is %d. %n", sum );
        //System.out.printf( "The sum is %d.%n", sum ); // display result
        //// display the message in dialog
        JOptionPane.showMessageDialog(null,sum);
        
        
    } // end main
    
    
} // end class Addition


