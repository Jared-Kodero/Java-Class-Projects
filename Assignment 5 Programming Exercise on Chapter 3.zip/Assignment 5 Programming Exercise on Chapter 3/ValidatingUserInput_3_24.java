
/**
 * Validating User Input.
 *
 * @author (Jared M Kodero)
 * @version (1/24/2019)
 */
import java.util.Scanner;
public class ValidatingUserInput_3_24
{
  public static void main(String[] args)
  {
      // Create a scanner Object
      Scanner input =new Scanner(System.in);
      
      // Initializing variables
      int passes = 0; 
      int failures = 0;
      int result = 0;
      int studentCounter = 1;
      
      while (studentCounter < 10 )
      {
          System.out.print("(Enter The Result 1 = pass, 2 = fail): ");//Prompt
          result = input.nextInt();
          
              studentCounter++;
           
          if (!(result > 2)) //Validating input.
             {
                   // If , else is nested in the while statement
                    if (result == 1)
                      passes = passes + 1;
                   else 
                      failures =failures + 1;
            
                  studentCounter = studentCounter + 1;
            
            }
          
            //Termination Phase
            System.out.printf("Passed: %d%nFailed: %d%n", passes, failures);
      
                if (passes > 8)
                
                    System.out.printf("Bonus to Instructor!");
      
      } //End While
      
      
      
   }
}// End Class
