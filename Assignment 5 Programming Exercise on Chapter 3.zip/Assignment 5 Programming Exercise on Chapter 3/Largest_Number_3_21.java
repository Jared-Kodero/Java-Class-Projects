
/**
 * Finds the Largest Number.
 *
 * @author (Jared M Kodero)
 * @version (1/23/2019)
 */

import java.util.Scanner;
public class Largest_Number_3_21
{
    public static void main(String[] args)
    {
        //// create Scanner object to obtain input from command window
        Scanner input = new Scanner(System.in);
        // initialize phase
       
      
        int number = 0; // the interger most recently entered by the user.
        int largest = 0;// The largest number found  so far
        int nCounter= 1;// counter
       

        while( nCounter <= 10 )// Loop X 10 
        {

            System.out.printf("%d Enter a number: ",nCounter);//Prompt
            number = input.nextInt();//Input next number
            largest = Math.max(number,largest);
            nCounter = nCounter + 1;
            
            
            

        }

        System.out.printf("The largest number is: %d\n", largest);

    }


}
