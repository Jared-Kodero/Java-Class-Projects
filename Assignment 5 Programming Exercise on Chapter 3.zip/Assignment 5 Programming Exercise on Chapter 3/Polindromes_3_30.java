
/**
 * Polindromes.
 *
 * @author (Jared M Kodero)
 * @version (1/24/2019)
 */
import java.util.Scanner;
public class Polindromes_3_30
{
  public static void main(String arg[]) 
    
    {
        
        //Create new scanner item
            Scanner sc=new Scanner(System.in);
            
            //Initialization Phase
            int num;
            int t;
            int s;
            int rem;
            int digits;
            
        System.out.println("Enter 5-Digit  number ");
            num=sc.nextInt();
            
            
             if ( (num <= 99999) & ( num > 9999 ) )
            {
               
                    t=num;
                    for(s=0;num>0;num/=10)
                        {
                            rem=num%10;
                            s=(s*10)+rem;
                        }
                            if(s==t)
                            System.out.println(t+" is a palindrome number ");
                  else
                            System.out.println(t+" is not a palindrome number ");
                      
            } 
            
            
            else
            {
        
                  System.out.println( "Number must be 5 digits"); 
            }
    }
}


        

