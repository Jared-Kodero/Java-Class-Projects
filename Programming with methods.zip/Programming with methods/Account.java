
/**
 * Removing dulicated methord in Main.
 *
 * @author (2/10/2019)
 * @version (Jared M Kodero)
 */
public class Account
{   
   
        private String name;
        private double balance;

        public Account(String name, double balance)
       {
           this.name=name;
           if(balance>0.0)
           this.balance=balance;
       }
        public void deposit(double depositAmount)
        {
            if(depositAmount>0.0)
            balance += depositAmount;
        }
        public void withdrawl(double withdrawlAmount)
        {
            if(balance>withdrawlAmount)
            {
                balance=balance-withdrawlAmount;
            }
            else
            System.out.println("Withdrawl amount exceeded account balance");
        }
        public double getBalance()
        {
            return balance;
        }
        public void setName(String name)
       {
        this.name=name;
        }
    public String getName()
    {
        return name;
    }

}
   
 // end class Account
