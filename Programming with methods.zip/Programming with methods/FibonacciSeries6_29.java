
/**
 * Fibonaci Series.
 *
 * @author (Jared M Kodero)
 * @version (2/10/2019)
 */
import java.util.Scanner;
public class FibonacciSeries6_29
{
       

       public static void main(String[] args){

        Scanner sc = new Scanner(System.in);



        System.out.print("Enter nth number to calculate fibonacci to: ");

        System.out.println(fibonacci(sc.nextInt()));

    }

    // fibonacci

    public static double fibonacci(double n){

        // base case (not possible to positively reduce)

        if(n <= 1)

            return n;

        else

            return fibonacci(n-1) + fibonacci(n-2);

    }
}